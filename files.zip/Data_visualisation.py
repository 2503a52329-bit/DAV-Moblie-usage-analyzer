# Data_visualisation.py - Mobile Usage Analyzer
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("clean_dataset.csv")
os.makedirs("charts", exist_ok=True)

# 1. Screen time distribution
plt.figure(figsize=(7, 5))
sns.histplot(df["daily_screen_time_hrs"], bins=7, kde=True)
plt.title("Daily Screen Time Distribution")
plt.xlabel("Hours per day")
plt.savefig("charts/1_screen_time_distribution.png")
plt.close()

# 2. Most used app
plt.figure(figsize=(7, 5))
sns.countplot(data=df, x="most_used_app")
plt.title("Most Used App")
plt.savefig("charts/2_most_used_app.png")
plt.close()

# 3. Main purpose
plt.figure(figsize=(6, 6))
df["main_purpose"].value_counts().plot(kind="pie", autopct="%1.0f%%")
plt.title("Main Purpose of Phone Use")
plt.ylabel("")
plt.savefig("charts/3_main_purpose.png")
plt.close()

# 4. Average time per activity
plt.figure(figsize=(7, 5))
df[["social_media_time_hrs", "gaming_time_hrs",
    "study_work_time_hrs", "entertainment_time_hrs"]].mean().plot(kind="bar")
plt.title("Average Time per Activity")
plt.ylabel("Hours")
plt.xticks(rotation=20)
plt.tight_layout()
plt.savefig("charts/4_activity_time.png")
plt.close()

# 5. Screen time by occupation
plt.figure(figsize=(7, 5))
sns.boxplot(data=df, x="occupation", y="daily_screen_time_hrs")
plt.title("Screen Time: Student vs Employee")
plt.savefig("charts/5_screen_time_occupation.png")
plt.close()

# 6. Screen time vs sleep
plt.figure(figsize=(7, 5))
sns.scatterplot(data=df, x="daily_screen_time_hrs", y="sleep_duration_hrs")
plt.title("Screen Time vs Sleep")
plt.savefig("charts/6_screen_time_vs_sleep.png")
plt.close()

# 7. Notifications vs phone checks
plt.figure(figsize=(7, 5))
sns.scatterplot(data=df, x="notifications_per_day", y="phone_checks_per_day")
plt.title("Notifications vs Phone Checks")
plt.savefig("charts/7_notifications_vs_checks.png")
plt.close()

# 8. Feels distracted vs screen time
plt.figure(figsize=(7, 5))
sns.boxplot(data=df, x="feels_distracted", y="daily_screen_time_hrs")
plt.title("Screen Time vs Feeling Distracted")
plt.savefig("charts/8_distracted_vs_screen_time.png")
plt.close()

# 9. Phone before sleep vs sleep hours
plt.figure(figsize=(7, 5))
sns.boxplot(data=df, x="phone_before_sleep", y="sleep_duration_hrs")
plt.title("Sleep Hours: Phone Before Sleep")
plt.savefig("charts/9_phone_before_sleep.png")
plt.close()

# 10. Correlation heatmap
plt.figure(figsize=(9, 7))
sns.heatmap(df.select_dtypes("number").corr(), annot=True, fmt=".2f", cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.savefig("charts/10_correlation_heatmap.png")
plt.close()

print("Done. 10 charts saved in the 'charts' folder.")
