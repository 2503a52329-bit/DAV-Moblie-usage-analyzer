# data_cleaning.py - Mobile Usage Analyzer
import pandas as pd

# 1. Load the data
df = pd.read_excel("Mobile_usage_analyzer-dataset.xlsx")
print("Shape:", df.shape)

# 2. Make column names simple (lowercase, no spaces)
df.columns = (df.columns.str.lower()
              .str.replace("/", "_")
              .str.replace(" ", "_")
              .str.replace("-", "_")
              .str.replace("(", "")
              .str.replace(")", ""))
print(df.columns.tolist())

# 3. Remove the word "hours" so the columns become numbers (3.3 hours -> 3.3)
hour_columns = ["daily_screen_time_hrs", "social_media_time_hrs", "gaming_time_hrs",
                "study_work_time_hrs", "entertainment_time_hrs", "sleep_duration_hrs"]
for col in hour_columns:
    df[col] = df[col].str.replace("hours", "").str.strip().astype(float)

# 4. Fix app names
df["most_used_app"] = df["most_used_app"].replace({"Youtube": "YouTube", "Whatsapp": "WhatsApp"})

# 5. Check missing values and duplicates
print("Missing values:", df.isnull().sum().sum())
print("Duplicate rows:", df.duplicated().sum())
df = df.drop_duplicates()
df = df.dropna()

# 6. Add a few useful columns
df["total_activity_hrs"] = (df["social_media_time_hrs"] + df["gaming_time_hrs"]
                            + df["study_work_time_hrs"] + df["entertainment_time_hrs"])
df["screen_time_level"] = pd.cut(df["daily_screen_time_hrs"], bins=[0, 4, 6, 24],
                                 labels=["Low", "Medium", "High"])
df["age_group"] = pd.cut(df["age"], bins=[17, 19, 21, 23],
                         labels=["18-19", "20-21", "22-23"])

# 7. Save the clean data
df.to_csv("clean_dataset.csv", index=False)
print("Clean data saved. Shape:", df.shape)
