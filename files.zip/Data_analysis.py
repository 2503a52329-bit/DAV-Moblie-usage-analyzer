# Data_analysis.py - Mobile Usage Analyzer
import pandas as pd
from scipy import stats

df = pd.read_csv("clean_dataset.csv")

# 1. Basic statistics
print("Total respondents:", len(df))
print(df.describe().round(2))

# 2. Counts of categories
print(df["most_used_app"].value_counts())
print(df["main_purpose"].value_counts())
print(df["gender"].value_counts())
print(df["occupation"].value_counts())

# 3. Percentages
print("Use phone before sleep (%):", (df["phone_before_sleep"] == "Yes").mean() * 100)
print("Feel distracted (%):", (df["feels_distracted"] == "Yes").mean() * 100)
print("Want to reduce usage (%):", (df["wants_to_reduce_usage"] == "Yes").mean() * 100)

# 4. Average values by group
print(df.groupby("gender")[["daily_screen_time_hrs", "sleep_duration_hrs"]].mean().round(2))
print(df.groupby("occupation")[["daily_screen_time_hrs", "sleep_duration_hrs"]].mean().round(2))
print(df.groupby("feels_distracted")["daily_screen_time_hrs"].mean().round(2))
print(df.groupby("phone_before_sleep")["sleep_duration_hrs"].mean().round(2))

# 5. Average time per activity
print(df[["social_media_time_hrs", "gaming_time_hrs",
          "study_work_time_hrs", "entertainment_time_hrs"]].mean().round(2))

# 6. Correlation
print(df["daily_screen_time_hrs"].corr(df["sleep_duration_hrs"]))
print(df["notifications_per_day"].corr(df["phone_checks_per_day"]))

# 7. Simple statistical tests (p-value below 0.05 means a real difference)
distracted = df[df["feels_distracted"] == "Yes"]["daily_screen_time_hrs"]
not_distracted = df[df["feels_distracted"] == "No"]["daily_screen_time_hrs"]
print("Distracted vs not (t-test) p-value:", stats.ttest_ind(distracted, not_distracted).pvalue)

bed_yes = df[df["phone_before_sleep"] == "Yes"]["sleep_duration_hrs"]
bed_no = df[df["phone_before_sleep"] == "No"]["sleep_duration_hrs"]
print("Phone before sleep vs sleep (t-test) p-value:", stats.ttest_ind(bed_yes, bed_no).pvalue)

# 8. Save a summary
df.describe().round(2).to_csv("analysis_summary.csv")
print("Done. Summary saved to analysis_summary.csv")
